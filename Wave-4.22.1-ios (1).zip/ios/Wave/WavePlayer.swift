import UIKit
import AVFoundation
import MediaPlayer

/// Wave 4.22.0: native playback engine.
///
/// Before 4.22 the sound was played by WebKit (<audio> + Web Audio + hls.js inside the WKWebView). WebKit owned the
/// audio session and the lock-screen card, suspended the AudioContext in the background and dropped the card after a
/// pause — hence the many workarounds in WaveViewController. Now every <audio> of the page is a thin proxy
/// (WavePlayerShim.swift) and the sound is played here by AVPlayer:
///  * one AVPlayer per <audio> element of the page («deck»), so the crossfade of app.js keeps working;
///  * HLS is played natively by AVPlayer (hls.js is not used on iOS);
///  * the audio session, interruptions (calls, Siri), headphones, the lock-screen card and its buttons are native
///    and work even while the page is asleep;
///  * when the page sleeps in the background and a track ends, the next track already resolved by the page
///    ("hint") is started natively; the page adopts that player when it wakes up.
final class WavePlayer: NSObject {

    // MARK: types

    final class Deck {
        var id: String
        var sid: String
        let url: URL
        let player = AVPlayer()
        var item: AVPlayerItem?
        var wantPlay = false
        var volume: Float = 1
        var rate: Float = 1
        var preservesPitch = true
        var loop = false
        var everReady = false
        var ended = false
        var pendingSeek: Double?
        var sk = 0
        var retried = false
        var preRetries = 0
        var retryPos = 0.0
        var handoff = false
        var lastTick = Date.distantPast
        var lastProgress = Date.distantPast
        var itemObs: [NSKeyValueObservation] = []
        var itemNotes: [NSObjectProtocol] = []
        var playerObs: [NSKeyValueObservation] = []
        var timeObserver: Any?

        init(id: String, sid: String, url: URL) {
            self.id = id
            self.sid = sid
            self.url = url
            player.automaticallyWaitsToMinimizeStalling = true
            player.actionAtItemEnd = .pause
        }

        var ready: Bool { item?.status == .readyToPlay }
        var time: Double {
            let t = player.currentTime().seconds
            return t.isFinite ? max(0, t) : 0
        }
        /// seconds; -1 = live stream; nil = not known yet
        var duration: Double? {
            guard let it = item, it.status == .readyToPlay else { return nil }
            let d = it.duration
            if d.isIndefinite { return -1 }
            let s = d.seconds
            return s.isFinite && s > 0 ? s : nil
        }
        var isPlayingNow: Bool { player.timeControlStatus == .playing }
        var nearEnd: Bool {
            guard let d = duration, d > 0 else { return false }
            return time >= d - 0.6
        }
    }

    struct Meta {
        var state = "stopped"
        var title = ""
        var artist = ""
        var cover = ""
        var duration = 0.0
        var position = 0.0
        var liked = false
    }

    struct Hint {
        let url: URL
        let title: String
        let artist: String
        let cover: String
        let duration: Double
        let expires: Date
    }

    // MARK: wiring (set by WaveViewController)

    /// runs JavaScript in the page
    var sendJS: ((String) -> Void)?
    /// asks the page to do something (`waveRemote(action, arg)`): next / prev / like / play without a player
    var onRemote: ((String, Int) -> Void)?
    /// a lock-screen command woke the app: check that the Rust core is still alive
    var onWake: (() -> Void)?

    // MARK: state

    private var decks: [String: Deck] = [:]
    private var activeId: String?
    private var currentSid = ""
    private var meta = Meta()
    private var hint: Hint?
    private var artwork: MPMediaItemArtwork?
    private var artworkURL = ""
    private var outbox: [[String: Any]] = []
    private var flushScheduled = false
    private var sessionActive = false
    private var isBackground = false
    private var bgAt = Date.distantPast
    private var interruptedNow = false
    private var systemPaused = Set<String>()
    private var lastJsPlay = Date.distantPast
    private var lastActiveVolume: Float = 1
    private var handoffWork: DispatchWorkItem?
    private var nextWork: DispatchWorkItem?
    private var handoffSeq = 0

    override init() {
        super.init()
        isBackground = UIApplication.shared.applicationState == .background
        let nc = NotificationCenter.default
        let s = AVAudioSession.sharedInstance()
        nc.addObserver(self, selector: #selector(interrupted(_:)), name: AVAudioSession.interruptionNotification, object: s)
        nc.addObserver(self, selector: #selector(routeChanged(_:)), name: AVAudioSession.routeChangeNotification, object: s)
        nc.addObserver(self, selector: #selector(mediaReset(_:)), name: AVAudioSession.mediaServicesWereResetNotification, object: s)
        nc.addObserver(self, selector: #selector(enteredBackground), name: UIApplication.didEnterBackgroundNotification, object: nil)
        nc.addObserver(self, selector: #selector(enteringForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
        setupRemote()
    }

    // MARK: page -> native

    func handle(_ body: Any) {
        guard let m = body as? [String: Any], let op = m["op"] as? String else { return }
        let id = m["id"] as? String ?? ""
        switch op {
        case "hello": hello(m["sid"] as? String ?? "")
        case "load": load(id: id, m)
        case "hint": setHint(m)
        case "active":
            guard activeId != id else { return }
            activeId = id
            refreshNowPlaying()
        default:
            guard let d = decks[id] else {
                if op != "release" { sendJS?("window.__waveNA&&__waveNA.gone(\(js(id)))") }
                return
            }
            switch op {
            case "play": jsPlay(d)
            case "pause":
                if isBackground && d.wantPlay && Date().timeIntervalSince(bgAt) < 5 && !interruptedNow {
                    NSLog("[wave] page pause ignored right after background")
                    emit(d, "playing")
                    break
                }
                d.wantPlay = false
                systemPaused.remove(d.id)
                d.player.pause()
                refreshNowPlaying()
            case "seek":
                d.sk = max(d.sk, Int(num(m["sk"])))
                seek(d, num(m["t"]), notifySeeking: false)
            case "vol":
                d.volume = Float(max(0, min(1, num(m["v"], 1))))
                d.player.volume = d.volume
                if d.id == activeId && d.volume > 0.05 { lastActiveVolume = d.volume }
            case "rate": setRate(d, Float(num(m["v"], 1)))
            case "pitch":
                d.preservesPitch = (m["v"] as? Bool) ?? true
                d.item?.audioTimePitchAlgorithm = d.preservesPitch ? .spectral : .varispeed
            case "loop": d.loop = (m["v"] as? Bool) ?? false
            case "release": release(d)
            default: break
            }
        }
    }

    /// the lock-screen metadata the page sends (WaveAndroid.media); the position comes from the player itself
    func updateMeta(_ json: String) {
        guard let data = json.data(using: .utf8),
              let d = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return }
        // a native hand-off plays a track the sleeping page does not know yet: keep its card
        if activeDeck()?.handoff == true { return }
        meta.state = d["state"] as? String ?? "stopped"
        meta.title = d["title"] as? String ?? ""
        meta.artist = d["artist"] as? String ?? ""
        meta.duration = num(d["duration"])
        meta.position = num(d["position"])
        meta.liked = (d["liked"] as? Bool) ?? false
        setCover(d["cover"] as? String ?? "")
        refreshNowPlaying()
    }

    /// the page is gone (WebContent process died / reload): its players become orphans until a new page adopts them
    func pageGone() {
        currentSid = ""
    }

    // MARK: decks

    private func hello(_ sid: String) {
        currentSid = sid
        for d in Array(decks.values) where d.sid != sid && !d.handoff {
            // the track that still plays continues; the new page adopts it if it loads the same stream
            if !d.wantPlay { release(d) }
        }
    }

    private func load(id: String, _ m: [String: Any]) {
        guard !id.isEmpty, let s = m["url"] as? String, let url = URL(string: s) else { return }
        if let old = decks[id] { release(old) }
        let vol = Float(max(0, min(1, num(m["vol"], 1))))
        let rate = Float(num(m["rate"], 1))
        let pp = (m["pitch"] as? Bool) ?? (m["pp"] as? Bool) ?? true
        let loop = (m["loop"] as? Bool) ?? false

        // adopt a player of an earlier page or of a background hand-off that plays the same stream
        if let o = decks.values.first(where: { ($0.handoff || $0.sid != currentSid) && $0.url == url }) {
            decks.removeValue(forKey: o.id)
            if activeId == o.id { activeId = id }
            o.id = id
            o.sid = currentSid
            o.handoff = false
            o.loop = loop
            o.volume = max(vol, o.volume)
            o.player.volume = o.volume
            if o.preservesPitch != pp {
                o.preservesPitch = pp
                o.item?.audioTimePitchAlgorithm = pp ? .spectral : .varispeed
            }
            decks[id] = o
            setRate(o, rate)
            emit(o, "adopted", ["playing": o.wantPlay])
            if o.ready {
                for e in ["durationchange", "loadedmetadata", "loadeddata", "canplay", "canplaythrough"] { emit(o, e) }
            }
            emit(o, "timeupdate")
            refreshNowPlaying()
            return
        }

        let d = makeDeck(id: id, sid: currentSid, url: url)
        d.volume = vol
        d.player.volume = vol
        d.rate = rate > 0 ? rate : 1
        d.preservesPitch = pp
        d.loop = loop
        decks[id] = d
        attachItem(d, at: nil)
    }

    private func makeDeck(id: String, sid: String, url: URL) -> Deck {
        let d = Deck(id: id, sid: sid, url: url)
        d.playerObs = [
            d.player.observe(\.timeControlStatus, options: [.new]) { [weak self, weak d] _, _ in
                self?.onMain { [weak self] in
                    guard let self = self, let d = d else { return }
                    self.controlStatusChanged(d)
                }
            },
        ]
        d.timeObserver = d.player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.25, preferredTimescale: 600), queue: .main) { [weak self, weak d] _ in
            guard let self = self, let d = d else { return }
            self.tick(d)
        }
        return d
    }

    private func attachItem(_ d: Deck, at start: Double?) {
        detachItem(d)
        let it = AVPlayerItem(asset: AVURLAsset(url: d.url))
        it.audioTimePitchAlgorithm = d.preservesPitch ? .spectral : .varispeed
        d.item = it
        d.everReady = false
        d.ended = false
        if let s = start, s > 0 { d.pendingSeek = s } else { d.pendingSeek = nil }
        d.itemObs = [
            it.observe(\.status, options: [.new]) { [weak self, weak d] _, _ in
                self?.onMain { [weak self] in
                    guard let self = self, let d = d, d.item === it else { return }
                    self.itemStatusChanged(d)
                }
            },
            it.observe(\.isPlaybackLikelyToKeepUp, options: [.new]) { [weak self, weak d] _, _ in
                self?.onMain { [weak self] in
                    guard let self = self, let d = d, d.item === it, d.everReady, it.isPlaybackLikelyToKeepUp else { return }
                    self.emit(d, "canplaythrough")
                }
            },
            it.observe(\.loadedTimeRanges, options: [.new]) { [weak self, weak d] _, _ in
                self?.onMain { [weak self] in
                    guard let self = self, let d = d, d.item === it else { return }
                    if Date().timeIntervalSince(d.lastProgress) < 1 { return }
                    d.lastProgress = Date()
                    self.emit(d, "progress")
                }
            },
            it.observe(\.duration, options: [.new]) { [weak self, weak d] _, _ in
                self?.onMain { [weak self] in
                    guard let self = self, let d = d, d.item === it, d.everReady else { return }
                    self.emit(d, "durationchange")
                    self.refreshNowPlaying()
                }
            },
        ]
        let nc = NotificationCenter.default
        d.itemNotes = [
            nc.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: it, queue: .main) { [weak self, weak d] _ in
                guard let self = self, let d = d else { return }
                self.didEnd(d)
            },
            nc.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: it, queue: .main) { [weak self, weak d] n in
                guard let self = self, let d = d else { return }
                let err = n.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error
                self.failed(d, err?.localizedDescription)
            },
        ]
        d.player.replaceCurrentItem(with: it)
    }

    private func detachItem(_ d: Deck) {
        d.itemObs.forEach { $0.invalidate() }
        d.itemObs = []
        d.itemNotes.forEach { NotificationCenter.default.removeObserver($0) }
        d.itemNotes = []
        d.item = nil
    }

    private func release(_ d: Deck) {
        d.wantPlay = false
        d.player.pause()
        detachItem(d)
        d.playerObs.forEach { $0.invalidate() }
        d.playerObs = []
        if let o = d.timeObserver { d.player.removeTimeObserver(o) }
        d.timeObserver = nil
        d.player.replaceCurrentItem(with: nil)
        if decks[d.id] === d { decks.removeValue(forKey: d.id) }
        systemPaused.remove(d.id)
        refreshNowPlaying()
    }

    // MARK: transport

    private func jsPlay(_ d: Deck) {
        lastJsPlay = Date()
        handoffWork?.cancel()
        nextWork?.cancel()
        // the page plays something itself: players it did not adopt are not needed any more
        for o in Array(decks.values) where o !== d && (o.handoff || o.sid != currentSid) { release(o) }
        play(d)
    }

    private func play(_ d: Deck) {
        systemPaused.remove(d.id)
        if d.ended {
            d.ended = false
            d.player.seek(to: .zero)
        }
        d.wantPlay = true
        start(d)
        refreshNowPlaying()
    }

    private func start(_ d: Deck) {
        ensureSession()
        // a start position is applied first (itemStatusChanged starts the player after the seek)
        if !d.ready && d.pendingSeek != nil { return }
        if #available(iOS 16.0, *) { d.player.defaultRate = d.rate }
        d.player.rate = d.rate
    }

    private func setRate(_ d: Deck, _ v: Float) {
        guard v > 0, v.isFinite else { return }
        d.rate = v
        if #available(iOS 16.0, *) { d.player.defaultRate = v }
        if d.wantPlay && d.player.rate != 0 { d.player.rate = v }
        refreshNowPlaying()
    }

    private func seek(_ d: Deck, _ t: Double, notifySeeking: Bool) {
        guard t.isFinite else { return }
        let to = max(0, t)
        d.ended = false
        if notifySeeking { emit(d, "seeking", ["t": to]) }
        if !d.ready {
            d.pendingSeek = to
            return
        }
        doSeek(d, to, then: nil)
    }

    private func doSeek(_ d: Deck, _ t: Double, then: (() -> Void)?) {
        let time = CMTime(seconds: t, preferredTimescale: 1000)
        d.player.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero) { [weak self, weak d] finished in
            self?.onMain { [weak self] in
                guard let self = self, let d = d, finished else { return }
                self.emit(d, "seeked")
                self.emit(d, "timeupdate")
                self.refreshNowPlaying()
                then?()
            }
        }
    }

    // MARK: player callbacks

    private func itemStatusChanged(_ d: Deck) {
        guard let it = d.item else { return }
        switch it.status {
        case .readyToPlay:
            guard !d.everReady else { return }
            d.everReady = true
            d.preRetries = 0
            for e in ["durationchange", "loadedmetadata", "loadeddata", "canplay"] { emit(d, e) }
            if it.isPlaybackLikelyToKeepUp { emit(d, "canplaythrough") }
            if let p = d.pendingSeek {
                d.pendingSeek = nil
                doSeek(d, p) { [weak self, weak d] in
                    guard let self = self, let d = d, d.wantPlay else { return }
                    self.start(d)
                }
            } else if d.wantPlay {
                start(d)
            }
            refreshNowPlaying()
        case .failed:
            failed(d, it.error?.localizedDescription)
        default:
            break
        }
    }

    private func controlStatusChanged(_ d: Deck) {
        guard decks[d.id] === d else { return }
        switch d.player.timeControlStatus {
        case .playing:
            if d.wantPlay { emit(d, "playing") }
        case .waitingToPlayAtSpecifiedRate:
            if d.wantPlay && d.player.reasonForWaitingToPlay != .noItemToPlay { emit(d, "waiting") }
        case .paused:
            // paused by the system (call, Siri, headphones out, another app) — not by the page and not by the end
            if d.wantPlay && d.ready && !d.ended && !d.nearEnd && !interruptedNow && isBackground && Date().timeIntervalSince(bgAt) < 8 {
                // 4.22.1: going to the background (home, Telegram) must not stop the music
                ensureSession(force: true)
                start(d)
                break
            }
            if d.wantPlay && d.ready && !d.ended && !d.nearEnd {
                d.wantPlay = false
                systemPaused.insert(d.id)
                emit(d, "pause")
            }
        @unknown default:
            break
        }
        refreshNowPlaying()
    }

    private func tick(_ d: Deck) {
        guard decks[d.id] === d, d.wantPlay, d.isPlayingNow else { return }
        if d.retried && d.time > d.retryPos + 30 { d.retried = false }
        let gap = isBackground ? 1.0 : 0.25
        if Date().timeIntervalSince(d.lastTick) < gap - 0.03 { return }
        d.lastTick = Date()
        emit(d, "timeupdate")
    }

    private func didEnd(_ d: Deck) {
        guard decks[d.id] === d else { return }
        if d.loop {
            d.player.seek(to: .zero)
            if d.wantPlay { start(d) }
            return
        }
        d.ended = true
        let was = d.wantPlay
        d.wantPlay = false
        emit(d, "timeupdate")
        if was { emit(d, "pause") }
        emit(d, "ended")
        let wasActive = activeDeck() === d
        refreshNowPlaying()
        if wasActive && was && !d.handoff { scheduleHandoff(after: d) }
    }

    private func failed(_ d: Deck, _ message: String?) {
        guard decks[d.id] === d else { return }
        // a stream that already played broke (the core lost its socket while the app slept, a network switch):
        // wake the core and open the same stream again at the same second, once
        if d.everReady && !d.retried {
            d.retried = true
            let pos = d.time
            d.retryPos = pos
            let resume = d.wantPlay
            d.wantPlay = false
            onWake?()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self, weak d] in
                guard let self = self, let d = d, self.decks[d.id] === d else { return }
                self.attachItem(d, at: pos)
                d.wantPlay = resume
                if resume { self.start(d) }
            }
            return
        }
        if !d.everReady && d.preRetries < 3 {
            // 4.22.1: the first open of a stream often fails while the core / network is still waking up —
            // try the same address again quietly (0.4 s, 1.2 s, 2.5 s) instead of reporting an error at once
            d.preRetries += 1
            let delay = [0.4, 1.2, 2.5][d.preRetries - 1]
            let resume = d.wantPlay
            onWake?()
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self, weak d] in
                guard let self = self, let d = d, self.decks[d.id] === d else { return }
                let p = d.pendingSeek
                self.attachItem(d, at: p)
                d.wantPlay = resume
                if resume { self.start(d) }
            }
            return
        }
        d.wantPlay = false
        emit(d, "error", ["code": d.everReady ? 2 : 4, "msg": message ?? ""])
        refreshNowPlaying()
    }

    // MARK: background hand-off

    private func setHint(_ m: [String: Any]) {
        guard let s = m["url"] as? String, !s.isEmpty, let url = URL(string: s) else {
            hint = nil
            return
        }
        hint = Hint(url: url,
                    title: m["title"] as? String ?? "",
                    artist: m["artist"] as? String ?? "",
                    cover: m["cover"] as? String ?? "",
                    duration: num(m["duration"]),
                    expires: Date().addingTimeInterval(max(5, num(m["ttl"], 120))))
    }

    /// a track ended while the page sleeps: if the page does not start the next one within 1.5 s, start it here
    private func scheduleHandoff(after d: Deck) {
        guard isBackground, let h = hint, h.expires > Date(), h.url != d.url else { return }
        let endedAt = Date()
        handoffWork?.cancel()
        let w = DispatchWorkItem { [weak self] in
            guard let self = self, self.lastJsPlay < endedAt, self.isBackground else { return }
            self.startHandoff()
        }
        handoffWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: w)
    }

    private func startHandoff() {
        guard let h = hint, h.expires > Date() else { return }
        hint = nil
        let prev = activeDeck()
        handoffSeq += 1
        let d = makeDeck(id: "native-\(handoffSeq)", sid: currentSid, url: h.url)
        d.handoff = true
        d.rate = prev?.rate ?? 1
        d.preservesPitch = prev?.preservesPitch ?? true
        d.volume = lastActiveVolume
        d.player.volume = d.volume
        for o in decks.values where o.wantPlay {
            o.wantPlay = false
            o.player.pause()
            emit(o, "pause")
        }
        decks[d.id] = d
        attachItem(d, at: nil)
        activeId = d.id
        meta = Meta(state: "playing", title: h.title, artist: h.artist, cover: meta.cover,
                    duration: h.duration, position: 0, liked: false)
        setCover(h.cover)
        play(d)
    }

    // MARK: lock screen

    private func activeDeck() -> Deck? {
        if let id = activeId, let d = decks[id] { return d }
        return decks.values.first { $0.wantPlay }
    }

    private func refreshNowPlaying() {
        let center = MPNowPlayingInfoCenter.default()
        let d = activeDeck()
        if meta.state == "stopped" && !(d?.wantPlay ?? false) {
            if d == nil { center.nowPlayingInfo = nil }
            if d == nil { return }
        }
        if d == nil && meta.title.isEmpty { return }
        var dur = meta.duration, pos = meta.position, rate = 0.0, live = false
        if let d = d {
            if let du = d.duration {
                if du < 0 { live = true } else { dur = du }
            }
            pos = d.time
            rate = d.isPlayingNow ? Double(d.player.rate) : 0
        }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: meta.title,
            MPMediaItemPropertyArtist: meta.artist,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: dur > 0 ? min(pos, dur) : pos,
            MPNowPlayingInfoPropertyPlaybackRate: rate,
            MPNowPlayingInfoPropertyDefaultPlaybackRate: 1.0,
            MPNowPlayingInfoPropertyMediaType: MPNowPlayingInfoMediaType.audio.rawValue,
            MPNowPlayingInfoPropertyIsLiveStream: live,
        ]
        if dur > 0 && !live { info[MPMediaItemPropertyPlaybackDuration] = dur }
        if let a = artwork { info[MPMediaItemPropertyArtwork] = a }
        center.nowPlayingInfo = info
        let rc = MPRemoteCommandCenter.shared()
        rc.likeCommand.isActive = meta.liked
        rc.changePlaybackPositionCommand.isEnabled = !live
    }

    private func setCover(_ s: String) {
        guard s != artworkURL else { return }
        artworkURL = s
        artwork = nil
        guard !s.isEmpty, let url = URL(string: s) else { return }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data = data, let img = UIImage(data: data) else { return }
            DispatchQueue.main.async {
                guard let self = self, self.artworkURL == s else { return }
                self.artwork = MPMediaItemArtwork(boundsSize: img.size) { _ in img }
                self.refreshNowPlaying()
            }
        }.resume()
    }

    private func setupRemote() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.isEnabled = true
        c.pauseCommand.isEnabled = true
        c.togglePlayPauseCommand.isEnabled = true
        c.nextTrackCommand.isEnabled = true
        c.previousTrackCommand.isEnabled = true
        c.changePlaybackPositionCommand.isEnabled = true
        c.skipForwardCommand.isEnabled = false
        c.skipBackwardCommand.isEnabled = false
        c.seekForwardCommand.isEnabled = false
        c.seekBackwardCommand.isEnabled = false
        c.likeCommand.isEnabled = true
        c.likeCommand.localizedTitle = "Нравится"

        c.playCommand.addTarget { [weak self] _ in self?.remotePlay() ?? .commandFailed }
        c.pauseCommand.addTarget { [weak self] _ in self?.remotePause() ?? .commandFailed }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in
            guard let self = self else { return .commandFailed }
            return self.decks.values.contains(where: { $0.wantPlay }) ? self.remotePause() : self.remotePlay()
        }
        c.nextTrackCommand.addTarget { [weak self] _ in
            self?.remoteNext()
            return .success
        }
        c.previousTrackCommand.addTarget { [weak self] _ in
            guard let self = self else { return .commandFailed }
            if let d = self.activeDeck(), d.time > 4 {
                self.seek(d, 0, notifySeeking: true)
            } else {
                self.onRemote?("prev", 0)
            }
            return .success
        }
        c.changePlaybackPositionCommand.addTarget { [weak self] e in
            guard let self = self, let e = e as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            if let d = self.activeDeck() {
                self.seek(d, e.positionTime, notifySeeking: true)
            } else {
                self.onRemote?("seek", Int(e.positionTime * 1000))
            }
            return .success
        }
        c.likeCommand.addTarget { [weak self] _ in
            guard let self = self else { return .success }
            self.meta.liked.toggle()
            self.refreshNowPlaying()
            self.onWake?()
            self.onRemote?("like", 0)
            return .success
        }
    }

    private func remotePlay() -> MPRemoteCommandHandlerStatus {
        onWake?()
        if let d = activeDeck(), d.item != nil, d.item?.status != .failed {
            play(d)
            emit(d, "play")
        } else {
            // no player yet (fresh start, the page was reloaded): the page starts the track
            ensureSession()
            onRemote?("play", 0)
        }
        return .success
    }

    private func remotePause() -> MPRemoteCommandHandlerStatus {
        for d in decks.values where d.wantPlay {
            d.wantPlay = false
            systemPaused.remove(d.id)
            d.player.pause()
            emit(d, "pause")
        }
        refreshNowPlaying()
        return .success
    }

    private func remoteNext() {
        onRemote?("next", 0)
        guard isBackground else { return }
        // the page may be asleep: start the track it resolved ahead if it does not react
        let at = Date()
        nextWork?.cancel()
        let w = DispatchWorkItem { [weak self] in
            guard let self = self, self.lastJsPlay < at, self.isBackground else { return }
            self.startHandoff()
        }
        nextWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: w)
    }

    // MARK: audio session

    func ensureSession(force: Bool = false) {
        guard force || !sessionActive else { return }
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .default, options: [])
        do {
            try s.setActive(true)
            sessionActive = true
        } catch {
            NSLog("[wave] audio session: \(error)")
        }
    }

    @objc private func interrupted(_ n: Notification) {
        guard let raw = n.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
        onMain { [weak self] in
            guard let self = self else { return }
            if type == .began {
                self.interruptedNow = true
                self.sessionActive = false
                // AVPlayer is paused by the system; controlStatusChanged tells the page
                for d in self.decks.values where d.wantPlay {
                    d.wantPlay = false
                    self.systemPaused.insert(d.id)
                    self.emit(d, "pause")
                }
                self.refreshNowPlaying()
            } else {
                self.interruptedNow = false
                let opts = AVAudioSession.InterruptionOptions(rawValue: (n.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt) ?? 0)
                guard opts.contains(.shouldResume) else { self.systemPaused.removeAll(); return }
                let ids = self.systemPaused
                self.systemPaused.removeAll()
                for id in ids {
                    guard let d = self.decks[id] else { continue }
                    self.play(d)
                    self.emit(d, "play")
                }
            }
        }
    }

    @objc private func routeChanged(_ n: Notification) {
        guard let raw = n.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
              let reason = AVAudioSession.RouteChangeReason(rawValue: raw),
              reason == .oldDeviceUnavailable else { return }
        // headphones out: AVPlayer pauses by itself; a later interruption must not start the music again
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in self?.systemPaused.removeAll() }
    }

    @objc private func mediaReset(_ n: Notification) {
        onMain { [weak self] in
            guard let self = self else { return }
            self.sessionActive = false
            for d in Array(self.decks.values) {
                self.emit(d, "error", ["code": 2, "msg": "media services were reset"])
                self.release(d)
            }
        }
    }

    @objc private func enteredBackground() {
        isBackground = true
        bgAt = Date()
        // 4.22.1: WebKit may drop the shared audio session when the page is hidden — take it back and keep playing
        guard decks.values.contains(where: { $0.wantPlay }) else { return }
        ensureSession(force: true)
        for d in decks.values where d.wantPlay && !d.isPlayingNow { start(d) }
        for delay in [0.5, 1.5, 3.0] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                guard let self = self, self.isBackground, !self.interruptedNow else { return }
                for d in self.decks.values where d.wantPlay && d.ready && !d.isPlayingNow && d.player.timeControlStatus == .paused {
                    self.ensureSession(force: true)
                    self.start(d)
                }
            }
        }
    }

    @objc private func enteringForeground() {
        isBackground = false
        handoffWork?.cancel()
        nextWork?.cancel()
        // the page may have slept: give it the real positions at once
        for d in decks.values { emit(d, "timeupdate") }
    }

    // MARK: native -> page

    private func state(_ d: Deck) -> [String: Any] {
        var s: [String: Any] = ["t": d.time, "rs": readyState(d), "sk": d.sk]
        if let du = d.duration { s["d"] = du }
        if let it = d.item {
            s["buf"] = ranges(it.loadedTimeRanges)
            s["sk2"] = ranges(it.seekableTimeRanges)
        }
        return s
    }

    private func readyState(_ d: Deck) -> Int {
        guard let it = d.item, it.status == .readyToPlay else { return 0 }
        if it.isPlaybackLikelyToKeepUp || it.isPlaybackBufferFull { return 4 }
        if it.isPlaybackBufferEmpty { return 2 }
        return 3
    }

    private func ranges(_ v: [NSValue]) -> [[Double]] {
        v.compactMap { value -> [Double]? in
            let r = value.timeRangeValue
            let a = r.start.seconds, b = CMTimeRangeGetEnd(r).seconds
            return a.isFinite && b.isFinite ? [a, b] : nil
        }
    }

    private func emit(_ d: Deck, _ e: String, _ extra: [String: Any] = [:]) {
        var s = state(d)
        for (k, v) in extra { s[k] = v }
        outbox.append(["id": d.id, "e": e, "s": s])
        guard !flushScheduled else { return }
        flushScheduled = true
        DispatchQueue.main.async { [weak self] in self?.flush() }
    }

    private func flush() {
        flushScheduled = false
        guard !outbox.isEmpty else { return }
        let list = outbox
        outbox = []
        guard JSONSerialization.isValidJSONObject(list),
              let data = try? JSONSerialization.data(withJSONObject: list),
              let json = String(data: data, encoding: .utf8) else { return }
        sendJS?("window.__waveNA&&__waveNA.ev(\(json))")
    }

    // MARK: helpers

    private func onMain(_ f: @escaping () -> Void) {
        if Thread.isMainThread { f() } else { DispatchQueue.main.async(execute: f) }
    }

    private func num(_ v: Any?, _ fallback: Double = 0) -> Double {
        guard let n = v as? NSNumber else { return fallback }
        let d = n.doubleValue
        return d.isFinite ? d : fallback
    }
}

//! Wave Android no longer embeds Node.js. The Java class NodeRunner still loads «node» before «wavenode»,
//! so this library only has to exist; the whole backend lives in libwavenode.so (the `core` crate).
#[no_mangle]
pub extern "C" fn wave_node_stub() -> i32 {
    0
}

"use strict";
/* Wave 4.21.9 (iOS): player styles swapped, «Любимые исполнители» = Yandex + Wave time, About text,
   fewer WebView restarts (wave animation stops in the background), playback comes back after a restart */
(() => {
  const ok = (f) => { try { return f(); } catch (e) { return undefined; } };
  const root = document.documentElement;
  const isIOS = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.wave);
  const whenReady = (f, n = 0) => (typeof S !== "undefined" && S.settings ? f() : n < 120 && setTimeout(() => whenReady(f, n + 1), 250));

  /* 1. «Полноэкранный плеер»: the old «Яндекс» look is now «Wave» and back — keep what the user had picked by name */
  whenReady(() => ok(async () => {
    if (localStorage.getItem("wave.pswap4219")) return;
    localStorage.setItem("wave.pswap4219", "1");
    const p = S.settings.player;
    const np = p === "nowplaying" ? "cover" : p === "cover" ? "nowplaying" : null;
    if (!np) return;
    S.settings = await api("settings", { player: np });
    ok(() => applySettings());
  }));

  /* 2. «О программе»: the platform and the current version */
  const platform = () => (isIOS ? "iPhone" : root.hasAttribute("data-mobile") ? "Android" : "ПК");
  const fixAbout = () => ok(() => {
    document.querySelectorAll(".scard").forEach((c) => {
      if ((c.querySelector("h2")?.textContent || "").trim() !== "О программе") return;
      const p = c.querySelector("p");
      if (!p || p.dataset.w4219) return;
      p.dataset.w4219 = "1";
      p.textContent = `Wave ${S.version || "4.21.9"} для ${platform()}. Также есть версии для Android и ПК. Независимый клиент, не связан с Яндексом, SoundCloud, Audius или Spotify.`;
    });
  });

  /* 3. «Любимые исполнители»: Yandex top of the month (refreshed) plus the time listened in Wave.
        Yandex counts only what was played in its own apps, so Wave adds its own listening time to the same artist */
  const key = (n) => String(n || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  let topAt = 0, busy = false;
  const merged = (list) => {
    const local = new Map((S.artistTime || []).map((a) => [key(a.name), a.sec || 0]));
    return list.map((a) => ({ ...a, sec: (a.ymSec ?? a.sec ?? 0) + (local.get(key(a.name)) || 0), ymSec: a.ymSec ?? a.sec ?? 0 }))
      .sort((x, y) => y.sec - x.sec);
  };
  async function refreshTop(force) {
    if (busy || !S.settings?.ymToken || typeof topArtistsHtml !== "function") return;
    if (!force && Date.now() - topAt < 10 * 60 * 1000 && S.ymTop) return paintTop();
    busy = true;
    try {
      const r = await api("ym-top-artists", { force: true }).catch(() => null);
      if (Array.isArray(r) && r.length) { S.ymTop = r.map((a) => ({ ...a, ymSec: a.sec || 0 })); topAt = Date.now(); }
    } finally { busy = false; }
    paintTop();
  }
  function paintTop() {
    if (!S.ymTop?.length) return;
    const list = merged(S.ymTop);
    ok(() => {
      for (const id of ["fav-arts", "wx-ymtop-list"]) {
        const el = document.getElementById(id);
        if (el && el.dataset.sig !== JSON.stringify(list.map((a) => [a.name, Math.round(a.sec / 60)]))) {
          el.innerHTML = topArtistsHtml(list);
          el.dataset.sig = JSON.stringify(list.map((a) => [a.name, Math.round(a.sec / 60)]));
        }
      }
    });
  }

  /* 4. Fewer WebContent restarts: the canvas wave is the heaviest thing on the page — stop it while Wave is hidden */
  document.addEventListener("visibilitychange", () => ok(() => {
    if (typeof WaveFx === "undefined") return;
    if (document.hidden) WaveFx.setPaused(true);
    else if (!document.body.classList.contains("fp-open") && !(typeof lyOpen === "function" && lyOpen())) WaveFx.setPaused(false);
  }));

  /* 5. After iOS restarted the WebView (recover=1) the track that was playing continues from the same second */
  setInterval(() => ok(() => {
    const a = document.getElementById("audio") || document.querySelector("audio");
    if (!S.current || !a) return;
    localStorage.setItem("wave.play4219", JSON.stringify({ id: S.current.id, pos: a.currentTime || 0, playing: !a.paused, at: Date.now() }));
  }), 2000);
  if (/[?&]recover=1/.test(location.search)) {
    let tries = 0;
    const resume = () => ok(() => {
      const s = JSON.parse(localStorage.getItem("wave.play4219") || "null");
      if (!s || !s.playing || Date.now() - s.at > 3 * 60 * 1000) return;
      if (!S.current || S.current.id !== s.id) { if (++tries < 20) setTimeout(resume, 500); return; }
      const a = document.getElementById("audio") || document.querySelector("audio");
      if (a && !a.paused) return;
      if (window.waveRemote) {
        if (s.pos > 3) window.waveRemote("seek", Math.round(s.pos * 1000));
        window.waveRemote("play", 0);
      }
    });
    setTimeout(resume, 1800);
  }

  /* runs on every screen change */
  let raf = 0, lastRoute = "";
  const tick = () => {
    raf = 0;
    fixAbout();
    const r = ok(() => S.route) || "";
    if ((document.getElementById("fav-arts") || document.getElementById("wx-ymtop-list")) && r !== lastRoute) refreshTop(false);
    lastRoute = r;
  };
  whenReady(() => {
    new MutationObserver(() => { if (!raf) raf = requestAnimationFrame(tick); }).observe(document.body, { childList: true, subtree: true });
    tick();
  });
})();

/* Wave 4.15: analysis of decoded mono samples, entirely on the listener's computer. */
"use strict";
function analyzeMix(samples, sampleRate) {
  const count = 320,
    peaks = new Array(count).fill(0),
    n = samples.length;
  for (let i = 0; i < n; i++) {
    const k = Math.min(count - 1, Math.floor((i * count) / n)),
      v = Math.abs(samples[i]);
    if (v > peaks[k]) peaks[k] = v;
  }
  const hop = Math.max(1, Math.round(sampleRate / 100)),
    frames = Math.floor(n / hop),
    env = new Float32Array(frames);
  let last = 0;
  for (let j = 0; j < frames; j++) {
    let sum = 0;
    for (let k = 0; k < hop; k++) {
      const v = samples[j * hop + k];
      sum += v * v;
    }
    const rms = Math.sqrt(sum / hop);
    env[j] = Math.max(0, rms - last);
    last = rms * 0.8 + last * 0.2;
  }
  let bpm = null,
    score = 0;
  if (frames > 800) {
    let energy = 0;
    for (const v of env) energy += v * v;
    if (energy > 1e-7)
      for (let b = 70; b <= 180; b++) {
        const lag = Math.round((100 * 60) / b);
        let c = 0,
          e1 = 0,
          e2 = 0;
        for (let i = lag; i < frames; i++) {
          const x = env[i],
            y = env[i - lag];
          c += x * y;
          e1 += x * x;
          e2 += y * y;
        }
        const s = c / Math.sqrt(e1 * e2 + 1e-15);
        if (s > score) {
          score = s;
          bpm = b;
        }
      }
    if (score < 0.1) bpm = null;
  }
  // Goertzel energy in three octaves, across windows distributed over the recording.
  const chroma = Array(12).fill(0),
    win = 2048,
    windows = Math.min(48, Math.floor(n / win));
  if (windows >= 3) {
    for (let z = 0; z < windows; z++) {
      const start = Math.floor(((n - win) * (z + 0.5)) / windows);
      for (let midi = 48; midi < 84; midi++) {
        const f = 440 * Math.pow(2, (midi - 69) / 12);
        if (f >= sampleRate / 2) continue;
        const coeff = 2 * Math.cos((2 * Math.PI * f) / sampleRate);
        let q0 = 0,
          q1 = 0,
          q2 = 0;
        for (let i = 0; i < win; i++) {
          q0 = coeff * q1 - q2 + samples[start + i] * (0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (win - 1)));
          q2 = q1;
          q1 = q0;
        }
        chroma[midi % 12] += Math.sqrt(Math.max(0, q1 * q1 + q2 * q2 - coeff * q1 * q2));
      }
    }
  }
  const major = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88],
    minor = [6.33, 2.68, 3.52, 5.38, 2.6, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];
  const corr = (profile, root) => {
    let x = 0,
      y = 0,
      xy = 0,
      xx = 0,
      yy = 0;
    for (let i = 0; i < 12; i++) {
      const a = chroma[(i + root) % 12],
        b = profile[i];
      x += a;
      y += b;
      xx += a * a;
      yy += b * b;
      xy += a * b;
    }
    return (12 * xy - x * y) / Math.sqrt(Math.max(1e-15, (12 * xx - x * x) * (12 * yy - y * y)));
  };
  let choices = [];
  for (let r = 0; r < 12; r++) {
    choices.push({ root: r, minor: false, score: corr(major, r) }, { root: r, minor: true, score: corr(minor, r) });
  }
  choices.sort((a, b) => b.score - a.score);
  const best = choices[0],
    second = choices[1],
    notes = ["C", "C♯", "D", "E♭", "E", "F", "F♯", "G", "A♭", "A", "B♭", "B"],
    maj = [8, 3, 10, 5, 12, 7, 2, 9, 4, 11, 6, 1],
    min = [5, 12, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10];
  const key =
    best && best.score > 0.5 && best.score - second.score > 0.025
      ? {
          name: notes[best.root] + (best.minor ? "m" : ""),
          camelot: (best.minor ? min : maj)[best.root] + (best.minor ? "A" : "B"),
          confidence: Math.round(best.score * 100),
        }
      : null;
  return {
    peaks: peaks.map((v) => Math.round(v * 1000) / 1000),
    bpm,
    bpmConfidence: Math.round(score * 100),
    key,
    duration: n / sampleRate,
  };
}
function resampleMix(channels, inputRate, outputRate = 11025) {
  if (!Array.isArray(channels) || !channels.length || !Number.isFinite(inputRate) || inputRate <= 0)
    throw Error("Нет аудиоданных");
  const length = channels[0].length,
    n = Math.floor((length * outputRate) / inputRate),
    data = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const at = Math.min(length - 1, Math.floor((i * inputRate) / outputRate));
    let sum = 0;
    for (const c of channels) sum += c[at] || 0;
    data[i] = sum / channels.length;
  }
  return data;
}
if (typeof self !== "undefined" && typeof self.postMessage === "function")
  self.onmessage = (e) => {
    try {
      const d = e.data;
      const samples = d.channels ? resampleMix(d.channels, d.inputRate) : d.samples;
      self.postMessage({ result: analyzeMix(samples, d.channels ? 11025 : d.sampleRate) });
    } catch (err) {
      self.postMessage({ error: String(err.message || err) });
    }
  };
if (typeof module !== "undefined") module.exports = { analyzeMix, resampleMix };

/* Wave 4.21.8 — swipe-close animation, heart left of prev, remote/lock-screen seek, background audio watchdog,
   creator badge on own profile + avatar, showcase redesign hooks, social «Load failed» self-repair */
(() => {
  "use strict";
  const CREATORS = ["yota3301", "xantepxl"];
  const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const post = (m) => { try { window.webkit.messageHandlers.wave.postMessage(m); } catch (e) {} };
  const audioEl = () => $$("audio").find((a) => !a.paused && a.currentSrc) || document.getElementById("audio") || $("audio");
  const ax = () => { try { return typeof AX !== "undefined" ? AX : null; } catch (e) { return null; } };

  /* ---------- 1. seek from the lock screen / Control Center / notification: go through seekToTime ---------- */
  let remoteSeekUntil = 0;
  function doSeek(sec) {
    remoteSeekUntil = Date.now() + 2500;
    try {
      if (typeof seekToTime === "function") seekToTime(sec);
      else { const a = audioEl(); if (a) a.currentTime = sec; }
    } catch (e) { const a = audioEl(); if (a) try { a.currentTime = sec; } catch (_) {} }
    // tell the system the new position at once, otherwise it draws the old one and the slider jumps back
    setTimeout(pushPos, 60); setTimeout(pushPos, 600);
  }
  function pushPos() {
    const a = audioEl();
    if (!a) return;
    try {
      if (navigator.mediaSession && navigator.mediaSession.setPositionState && isFinite(a.duration) && a.duration > 0)
        navigator.mediaSession.setPositionState({ duration: a.duration, position: Math.min(a.currentTime, a.duration), playbackRate: a.playbackRate || 1 });
    } catch (e) {}
    try { a.dispatchEvent(new Event("seeked")); } catch (e) {}
  }
  function wrapRemote() {
    const orig = window.waveRemote;
    if (!orig || orig.__w4218) return;
    const w = function (a, arg) {
      if (a === "seek") return doSeek((Number(arg) || 0) / 1000);
      if (a === "like") {
        try { if (typeof toggleLike === "function" && typeof S !== "undefined" && S.current) { toggleLike(S.current); return; } } catch (e) {}
        const b = $('#fullplayer [data-cmd="like"]') || $('[data-cmd="like"]'); b && b.click(); return;
      }
      if (a === "play") kickAudio(true);
      return orig.apply(this, arguments);
    };
    w.__w4218 = true;
    window.waveRemote = w;
  }
  wrapRemote();
  setInterval(wrapRemote, 1500);
  try {
    navigator.mediaSession && navigator.mediaSession.setActionHandler("seekto", (d) => doSeek(d.seekTime || 0));
  } catch (e) {}

  const seekHandler = (d) => doSeek((d && d.seekTime) || 0);
  setInterval(() => {
    const a = audioEl();
    if (!a || a.paused) return;
    try { navigator.mediaSession && navigator.mediaSession.setActionHandler("seekto", seekHandler); } catch (e) {}
    if (Date.now() > remoteSeekUntil) pushPos();
  }, 2000);

  /* ---------- 2. iOS: in the background WebKit suspends the AudioContext — <audio> «plays» in silence.
     Resume the context; if it does not wake up, do what pause→play did by hand ---------- */
  let kickBusy = false;
  async function kickAudio(force) {
    if (kickBusy || window.__waveNA) return; // 4.22.1: native player — pause→play here stopped the music in the background
    const a = audioEl(), X = ax();
    if (!a || a.paused || !a.currentSrc) return;
    const ctx = X && X.ctx;
    if (!ctx || ctx.state === "running") return;
    kickBusy = true;
    try {
      try { await ctx.resume(); } catch (e) {}
      await new Promise((r) => setTimeout(r, 250));
      if (ctx.state !== "running" && !a.paused) {
        const t = a.currentTime;
        a.pause();
        try { await ctx.resume(); } catch (e) {}
        try { a.currentTime = t; } catch (e) {}
        try { await a.play(); } catch (e) {}
      }
    } finally { kickBusy = false; }
  }
  window.__waveKick = kickAudio;
  setInterval(() => kickAudio(false), 1500);
  document.addEventListener("visibilitychange", () => { setTimeout(kickAudio, 200); setTimeout(kickAudio, 1200); });
  const vis0 = window.waveVisible;
  if (vis0 && !vis0.__w4218) {
    const v = function (on) { const r = vis0.apply(this, arguments); setTimeout(kickAudio, 300); setTimeout(kickAudio, 1500); return r; };
    v.__w4218 = true; window.waveVisible = v;
  }

  /* ---------- 3. full player: ♥ left of «previous», dislike right of «next» ---------- */
  function fixRow() {
    $$(".m-fpctl .m-main").forEach((row) => {
      const like = $('[data-cmd="like"]', row), prev = $('[data-cmd="prev"]', row), next = $('[data-cmd="next"]', row), dis = $('[data-cmd="dislike"]', row);
      if (like && prev && like.nextElementSibling !== prev) row.insertBefore(like, prev);
      if (dis && next && next.nextElementSibling !== dis) next.after(dis);
      row.classList.add("wv-row8");
    });
  }

  /* ---------- 4. swipe-close animation for the full player (drag down) + edge swipe-back for pages ---------- */
  const fp = () => document.getElementById("fullplayer");
  const fpOpen = () => document.body.classList.contains("fp-open") && fp() && !fp().hidden;
  function closeFp() {
    try { if (typeof closeFull === "function") return closeFull(true); } catch (e) {}
    const b = $('[data-cmd="fp-close"]'); b && b.click();
  }
  let drag = null;
  const blocked = (t) => t.closest("[data-seek],[data-vol],input,select,textarea,.menu,#fpq,#sndp,.fpa-progress,#ly-text,.lyrics");
  document.addEventListener("touchstart", (e) => {
    if (e.touches.length !== 1) return;
    const t = e.touches[0];
    if (fpOpen()) return; // swipe-down of the player is handled (and animated) in mobile.js
    if (t.clientX < 24 && !isHome()) {
      drag = { kind: "back", x: t.clientX, y: t.clientY, t: Date.now(), dx: 0, on: false };
    }
  }, { passive: true, capture: true });
  document.addEventListener("touchmove", (e) => {
    if (!drag) return;
    const t = e.touches[0], dx = t.clientX - drag.x, dy = t.clientY - drag.y;
    if (drag.kind === "fp") {
      if (!drag.on) {
        if (Math.abs(dx) > 12 && Math.abs(dx) > Math.abs(dy)) { drag = null; return; }
        if (dy < 10) return;
        drag.on = true;
        fp().classList.add("wv-dragging");
      }
      drag.dy = Math.max(0, dy);
      const p = fp();
      p.style.transform = `translate3d(0,${drag.dy}px,0) scale(${1 - Math.min(drag.dy / innerHeight, 1) * 0.06})`;
      p.style.borderRadius = Math.min(28, drag.dy / 6) + "px";
      p.style.opacity = String(1 - Math.min(drag.dy / innerHeight, 1) * 0.35);
    } else {
      if (!drag.on) {
        if (Math.abs(dy) > 14 && Math.abs(dy) > Math.abs(dx)) { drag = null; return; }
        if (dx < 10) return;
        drag.on = true;
        pageEl() && pageEl().classList.add("wv-dragging");
      }
      drag.dx = Math.max(0, dx);
      const pg = pageEl();
      if (pg) { pg.style.transform = `translate3d(${drag.dx}px,0,0)`; pg.style.opacity = String(1 - Math.min(drag.dx / innerWidth, 1) * 0.4); }
    }
  }, { passive: true, capture: true });
  const endDrag = () => {
    if (!drag) return;
    const d = drag; drag = null;
    if (!d.on) return;
    const dt = Math.max(1, Date.now() - d.t);
    if (d.kind === "fp") {
      const p = fp(); p.classList.remove("wv-dragging");
      const go = d.dy > innerHeight * 0.22 || d.dy / dt > 0.6;
      p.classList.add("wv-anim");
      if (go) {
        p.style.transform = `translate3d(0,${innerHeight}px,0) scale(.94)`; p.style.opacity = "0";
        setTimeout(() => { closeFp(); resetFp(); }, 260);
      } else { resetFp(); }
    } else {
      const pg = pageEl(); if (!pg) return;
      pg.classList.remove("wv-dragging"); pg.classList.add("wv-anim");
      const go = d.dx > innerWidth * 0.3 || d.dx / dt > 0.5;
      if (go) {
        pg.style.transform = `translate3d(${innerWidth}px,0,0)`; pg.style.opacity = "0";
        setTimeout(() => { goBack(); pg.classList.remove("wv-anim"); pg.style.transform = "translate3d(-30px,0,0)"; pg.style.opacity = "0";
          requestAnimationFrame(() => { pg.classList.add("wv-anim"); pg.style.transform = ""; pg.style.opacity = ""; setTimeout(() => pg.classList.remove("wv-anim"), 300); }); }, 230);
      } else { pg.style.transform = ""; pg.style.opacity = ""; setTimeout(() => pg.classList.remove("wv-anim"), 300); }
    }
  };
  function resetFp() {
    const p = fp(); if (!p) return;
    p.style.transform = ""; p.style.opacity = ""; p.style.borderRadius = "";
    setTimeout(() => p.classList.remove("wv-anim"), 320);
  }
  document.addEventListener("touchend", endDrag, true);
  document.addEventListener("touchcancel", endDrag, true);
  // the native iOS edge swipe (right edge) also gets the same slide-out
  const edge0 = window.__waveEdge;
  if (typeof edge0 === "function" && !edge0.__w4218) {
    const ew = function (phase, dx, v) {
      if ((phase === "end" || phase === 3) && fpOpen() && Math.abs(dx) > innerWidth * 0.3) {
        const p = fp(); p.classList.add("wv-anim");
        p.style.transform = `translate3d(${-innerWidth}px,0,0)`; p.style.opacity = "0";
        setTimeout(() => { closeFp(); resetFp(); }, 250);
        return;
      }
      return edge0.apply(this, arguments);
    };
    ew.__w4218 = true; window.__waveEdge = ew;
  }
  const isHome = () => { try { return !S.route || S.route === "home" || S.route === "wave" || (S.route.name || S.route.r) === "home"; } catch (e) { return true; } };
  const pageEl = () => $("#content") || $("main") || $(".content");
  function goBack() {
    const b = $$('[data-cmd="back"],[aria-label="Назад"],.back,.m-back').find((x) => x.offsetParent);
    if (b) b.click(); else history.back();
  }

  /* ---------- 5. creator badge: own profile name + the person icon top-left of «Моя волна» ---------- */
  const SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="12" fill="#20A4F3"/><path d="M7 12.4l3.3 3.3L17.2 8.8" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  let me = null, meNick = null;
  function findCreator(o, depth = 0) {
    if (!o || depth > 4) return null;
    if (typeof o === "string") return CREATORS.includes(o.toLowerCase().replace(/^@/, "")) ? o : null;
    if (typeof o === "object") for (const k of Object.keys(o)) { if (/^(username|login|handle|user)$/i.test(k) || depth < 2) { const r = findCreator(o[k], depth + 1); if (r) return r; } }
    return null;
  }
  async function loadMe() {
    try {
      const r = await api("social", { op: "status" });
      me = findCreator(r);
      const nickOf = (o) => o && (o.nick || o.display_name || (o.profile && (o.profile.nick || o.profile.display_name)));
      meNick = nickOf(r) || nickOf(r && r.user) || nickOf(r && r.me) || null;
      try { if (me) localStorage.setItem("wave.creator", me); else localStorage.removeItem("wave.creator"); } catch (e) {}
    } catch (e) { try { me = localStorage.getItem("wave.creator"); } catch (_) {} }
    badgeMe();
  }
  function badgeMe() {
    if (!me) return;
    document.body.classList.add("wv-is-creator");
    // the big name on the own profile (XANTEP) — header blocks of the own / social profile
    $$(".phead h1, .phead h2, .phead b.nick, .profile-head h1, .soc-identity b, .m-profile h1, .prof-name").forEach((h) => {
      if (h.querySelector(".wv-verified") || (meNick && !h.textContent.trim().toLowerCase().includes(String(meNick).toLowerCase().slice(0, 3)))) return;
      const s = document.createElement("span"); s.className = "wv-verified"; s.title = "Это официальный профиль создателя Wave"; s.innerHTML = SVG; h.appendChild(s);
    });
    // 4.21.8b: no badge on the person icon of «Моя волна» — only inside the profile
    document.querySelectorAll(".wv-avb").forEach((x) => x.remove());
  }

  /* ---------- 6. «Нет связи с Wave / Load failed»: check the local core, ask iOS to revive it, retry by itself ---------- */
  async function health(ms = 1500) {
    const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
    try { const r = await fetch("/health?_=" + Date.now(), { cache: "no-store", signal: c.signal }); return r.ok; } catch (e) { return false; } finally { clearTimeout(t); }
  }
  let reviving = false;
  async function revive(btn) {
    if (reviving) return; reviving = true;
    if (btn) { btn.disabled = true; btn.dataset.txt = btn.dataset.txt || btn.textContent; btn.textContent = "Подключаюсь…"; }
    try {
      let ok = await health();
      if (!ok) {
        post({ t: "revive" }); // iOS: restart the core / reload the page (native side)
        for (let i = 0; i < 20 && !ok; i++) { await new Promise((r) => setTimeout(r, 400)); ok = await health(800); }
      }
      if (ok && btn) { btn.disabled = false; btn.textContent = btn.dataset.txt; btn.__w8 = true; btn.click(); }
      else if (!ok) { try { sessionStorage.setItem("wave.reviveAt", String(Date.now())); } catch (e) {} location.replace(location.pathname + location.search.replace(/([?&])recover=1/, "$1") + (location.search.includes("?") ? "&" : "?") + "recover=1"); }
    } finally { reviving = false; if (btn && btn.disabled) { btn.disabled = false; btn.textContent = btn.dataset.txt; } }
  }
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest("#soc-retry");
    if (!b) return;
    if (b.__w8) { b.__w8 = false; return; } // our own re-click goes through to the original handler
    e.stopImmediatePropagation(); e.preventDefault();
    revive(b);
  }, true);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) return;
    setTimeout(() => { const b = $("#soc-retry"); if (b && b.offsetParent) revive(b); }, 500);
  });
  window.__waveRevived = () => { const b = $("#soc-retry"); if (b) { b.__w8 = true; b.click(); } };

  /* ---------- observers ---------- */
  let q = 0;
  new MutationObserver(() => { if (q) return; q = requestAnimationFrame(() => { q = 0; fixRow(); badgeMe(); document.querySelectorAll(".showcase").forEach((s) => s.classList.add("wv-sc8")); }); })
    .observe(document.documentElement, { childList: true, subtree: true });
  const start = () => { fixRow(); setTimeout(loadMe, 1200); setInterval(loadMe, 5 * 60 * 1000); };
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", start) : start();
})();

//! JSON store (store.cjs): `{ ...defaults, ...file }`, writes are debounced and go through a temporary file.

use serde_json::Value;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::Duration;

pub struct Store {
    file: PathBuf,
    data: Mutex<Value>,
    dirty: AtomicBool,
    scheduled: AtomicBool,
    write: Mutex<()>,
    seq: AtomicU64,
    delay: u64,
}

impl Store {
    pub fn open(file: PathBuf, defaults: Value) -> Arc<Store> {
        let mut data = defaults;
        if let Ok(t) = std::fs::read_to_string(&file) {
            if let Ok(Value::Object(m)) = serde_json::from_str::<Value>(&t) {
                if let Value::Object(d) = &mut data {
                    for (k, v) in m {
                        d.insert(k, v);
                    }
                }
            }
        }
        Arc::new(Store {
            file,
            data: Mutex::new(data),
            dirty: AtomicBool::new(false),
            scheduled: AtomicBool::new(false),
            write: Mutex::new(()),
            seq: AtomicU64::new(0),
            delay: 1200,
        })
    }

    pub fn lock(&self) -> MutexGuard<'_, Value> {
        self.data.lock().unwrap_or_else(|e| e.into_inner())
    }

    pub fn save(self: &Arc<Self>) {
        self.dirty.store(true, Ordering::SeqCst);
        if self.scheduled.swap(true, Ordering::SeqCst) {
            return;
        }
        let me = self.clone();
        let spawn = tokio::runtime::Handle::try_current();
        match spawn {
            Ok(h) => {
                h.spawn(async move {
                    tokio::time::sleep(Duration::from_millis(me.delay)).await;
                    me.scheduled.store(false, Ordering::SeqCst);
                    let m2 = me.clone();
                    let _ = tokio::task::spawn_blocking(move || m2.flush_now()).await;
                });
            }
            Err(_) => {
                self.scheduled.store(false, Ordering::SeqCst);
                self.flush_now();
            }
        }
    }

    /// writes the current data right away (when dirty)
    pub fn flush_now(&self) {
        let _w = self.write.lock().unwrap_or_else(|e| e.into_inner());
        if !self.dirty.swap(false, Ordering::SeqCst) {
            return;
        }
        let json = match serde_json::to_string(&*self.lock()) {
            Ok(j) => j,
            Err(_) => return,
        };
        if let Some(dir) = self.file.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        let n = self.seq.fetch_add(1, Ordering::SeqCst) + 1;
        let tmp = PathBuf::from(format!("{}.{}.{}.tmp", self.file.display(), std::process::id(), n));
        if std::fs::write(&tmp, json).is_ok() {
            if std::fs::rename(&tmp, &self.file).is_err() {
                let _ = std::fs::remove_file(&tmp);
            }
        } else {
            let _ = std::fs::remove_file(&tmp);
        }
    }
}

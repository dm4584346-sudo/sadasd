//! HTTP client of the providers (providers/http.cjs): getJSON / getText with the same errors
//! («HTTP 404» with .status and .body), plus a raw client for the stream / picture proxies.

use crate::js::{E, R};
use reqwest::header::{HeaderMap, HeaderName, HeaderValue};
use serde_json::Value;
use std::sync::LazyLock;
use std::time::Duration;

pub const UA: &str =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36";

fn builder() -> reqwest::ClientBuilder {
    reqwest::Client::builder()
        .connect_timeout(Duration::from_secs(15))
        .pool_idle_timeout(Duration::from_secs(60))
        .tcp_keepalive(Duration::from_secs(30))
}

/// API requests (gzip / brotli decoded)
pub static CLIENT: LazyLock<reqwest::Client> = LazyLock::new(|| builder().build().expect("http client"));
/// streams and pictures passed through as they are (no decoding, no redirect surprises)
pub static RAW: LazyLock<reqwest::Client> =
    LazyLock::new(|| builder().no_gzip().no_brotli().no_deflate().build().expect("http client"));
/// for requests that must not follow redirects (Afisha city detection)
pub static NOREDIRECT: LazyLock<reqwest::Client> = LazyLock::new(|| {
    builder().redirect(reqwest::redirect::Policy::none()).build().expect("http client")
});

#[derive(Default, Clone)]
pub struct Opts {
    pub method: Option<&'static str>,
    pub headers: Vec<(String, String)>,
    pub body: Option<String>,
    pub timeout: Option<u64>,
}
impl Opts {
    pub fn new() -> Opts {
        Opts::default()
    }
    pub fn h(mut self, k: &str, v: &str) -> Opts {
        self.headers.push((k.to_string(), v.to_string()));
        self
    }
    pub fn post(mut self, body: String) -> Opts {
        self.method = Some("POST");
        self.body = Some(body);
        self
    }
    pub fn timeout(mut self, ms: u64) -> Opts {
        self.timeout = Some(ms);
        self
    }
}

pub fn headers(list: &[(String, String)]) -> HeaderMap {
    let mut h = HeaderMap::new();
    for (k, v) in list {
        if let (Ok(k), Ok(v)) = (HeaderName::from_bytes(k.as_bytes()), HeaderValue::from_str(v)) {
            h.insert(k, v);
        }
    }
    h
}

pub fn net_err(e: &reqwest::Error) -> E {
    if e.is_timeout() {
        E::new("The operation was aborted due to timeout")
    } else {
        E::new("fetch failed")
    }
}

/// `fetch(url, { headers, method, body, signal: AbortSignal.timeout(ms) })` → the response
pub async fn fetch(client: &reqwest::Client, url: &str, o: &Opts) -> R<reqwest::Response> {
    let m = match o.method.unwrap_or("GET") {
        "POST" => reqwest::Method::POST,
        "HEAD" => reqwest::Method::HEAD,
        _ => reqwest::Method::GET,
    };
    let mut rq = client.request(m, url).headers(headers(&o.headers));
    if let Some(b) = &o.body {
        rq = rq.body(b.clone());
    }
    if let Some(t) = o.timeout {
        rq = rq.timeout(Duration::from_millis(t));
    }
    rq.send().await.map_err(|e| net_err(&e))
}

async fn text_of(r: reqwest::Response) -> R<String> {
    r.text().await.map_err(|e| net_err(&e))
}

/// getJSON: { "User-Agent": UA, Accept: "application/json", ...headers }, 20 s by default
pub async fn get_json(url: &str, o: Opts) -> R<Value> {
    let mut hs = vec![("User-Agent".to_string(), UA.to_string()), ("Accept".to_string(), "application/json".to_string())];
    hs.extend(o.headers.iter().cloned());
    let o2 = Opts { headers: hs, timeout: Some(o.timeout.unwrap_or(20000)), ..o };
    let r = fetch(&CLIENT, url, &o2).await?;
    let st = r.status().as_u16();
    if !r.status().is_success() {
        let body = r.text().await.ok();
        return Err(E { msg: format!("HTTP {}", st), status: Some(st), body, ..Default::default() });
    }
    let t = text_of(r).await?;
    if t.is_empty() {
        return Ok(Value::Null);
    }
    serde_json::from_str(&t).map_err(|e| E::new(format!("Unexpected token in JSON: {}", e)))
}

/// getText: only the UA, 20 s by default
pub async fn get_text(url: &str, timeout: Option<u64>) -> R<String> {
    let o = Opts::new().h("User-Agent", UA).timeout(timeout.unwrap_or(20000));
    let r = fetch(&CLIENT, url, &o).await?;
    let st = r.status().as_u16();
    if !r.status().is_success() {
        return Err(E::new(format!("HTTP {}", st)).status(st));
    }
    text_of(r).await
}

/// a plain request whose body is read as text (status kept)
pub async fn text(url: &str, o: Opts) -> R<(u16, String, String)> {
    let r = fetch(&CLIENT, url, &o).await?;
    let st = r.status().as_u16();
    let final_url = r.url().to_string();
    let t = text_of(r).await?;
    Ok((st, final_url, t))
}

pub fn parse_json(t: &str) -> R<Value> {
    serde_json::from_str(t).map_err(|e| E::new(format!("Unexpected token in JSON: {}", e)))
}
